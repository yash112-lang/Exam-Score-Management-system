<?php
$conn = mysqli_connect("localhost", "root", "", "internship");
if(!$conn){
    print("There was an error while connecting to database.");
    echo "<br>";
}
else{
    // print("Connection is made successfully.");
}



?>