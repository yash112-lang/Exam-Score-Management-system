<?php
        require("connection.php");
        $sql = "SELECT * FROM $exam where id=$id";
        $result = mysqli_query($conn, $sql);
        $num =  mysqli_num_rows($result);
        if($num >0){
          while($row = mysqli_fetch_assoc($result)){
          $percentage = $row["percentage"];
          echo $percentage;
            }
        }
        
?>